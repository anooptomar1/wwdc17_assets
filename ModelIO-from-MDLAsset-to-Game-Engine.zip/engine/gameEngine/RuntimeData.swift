/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Runtime only data
*/

import Foundation
import MetalKit

struct PerFrameUniforms {
    // Per Frame Uniforms
    var cameraPos = vector_float3()

    var viewMatrix = matrix_identity_float4x4
    var viewProjectionMatrix = matrix_identity_float4x4

    // Per Light Properties
    var directionalLightInvDirection = vector_float3()
    var lightCol = vector_float3()
}

struct SkyUniform {
    var worldViewProjectionMatrix = matrix_identity_float4x4
}

struct MeshGPUData {
    var vtxBuffers = [MTLBuffer]()
    var indexBuffers = [MTLBuffer]()
    var textures = [MTLTexture?]()
    var drawData = [DrawData]()
}
