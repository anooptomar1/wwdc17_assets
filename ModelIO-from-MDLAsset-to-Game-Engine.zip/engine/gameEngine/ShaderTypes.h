/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Types used in shader, and bind points
*/

#ifndef ShaderTypes_h
#define ShaderTypes_h

#include <simd/simd.h>

// Buffer index values shared between shader and C code to ensure Metal shader buffer inputs match
//   Metal API buffer set calls
enum BufferIndices {
    kBufferIndexMeshPositions = 0,
    kBufferIndexMeshGenerics,
    kBufferIndexPerFrameUniforms,
    kBufferIndexMaterialUniforms,
    kBufferIndexPerMeshUniforms,
    kBufferIndexMeshUniformIndex,
    kBufferIndexSkyUniforms,
    kBufferIndexMeshPalettes,
    kBufferIndexMeshPaletteIndex,
    kBufferIndexMeshPaletteSize
};

// Attribute index values shared between shader and C code to ensure Metal shader vertex
//   attribute indices match the Metal API vertex descriptor attribute indices
enum VertexAttributes {
    kVertexAttributePosition  = 0,
    kVertexAttributeNormal,
    kVertexAttributeTexcoord,
    kVertexAttributeJointIndices,
    kVertexAttributeJointWeights
};

// Texture index values shared between shader and C code to ensure Metal shader texture indices
//   match indices of Metal API texture set calls
enum TextureIndices {
    kTextureIndexBaseColor = 0,
    kTextureIndexMetallic,
    kTextureIndexRoughness,
    kTextureIndexNormal,
    kTextureIndexAmbientOcclusion,
    kTextureIndexSkyMap,
    kNumTextureIndices
};

enum SceneTextureIndices {
    kTextureIndexIrradianceMap = kNumTextureIndices
};

enum FunctionConstantIndices {
    kFunctionConstantBaseColorMapIndex = 0,
    kFunctionConstantNormalMapIndex,
    kFunctionConstantMetallicMapIndex,
    kFunctionConstantRoughnessMapIndex,
    kFunctionConstantAmbientOcclusionMapIndex,
    kFunctionConstantIrradianceMapIndex,
    kNumFunctionConstantIndices
};

enum VertexConstantIndices {
    kVertexConstantPosition = kNumFunctionConstantIndices,
    kVertexConstantTexcoord,
    kVertexConstantNormal,
    kVertexConstantTangent,
    kVertexConstantBitangent
};

enum Viewports {
    kViewportLeft = 0,
    kViewportRight,
    kViewportNumViewports
};

enum QualityLevel {
    kQualityLevelHigh = 0,
    kQualityLevelMedium,
    kQualityLevelLow,
    kQualityNumLevels
};

#endif /* ShaderTypes_h */

