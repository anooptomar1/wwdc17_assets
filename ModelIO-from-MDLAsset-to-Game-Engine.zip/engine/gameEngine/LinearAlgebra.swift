/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Implementation math functions used for our sample
*/

import Foundation
import simd

func translation4x4(_ trans: simd.float3) -> matrix_float4x4 {
    return matrix_float4x4(columns: (simd.float4(1, 0, 0, 0),
                                     simd.float4(0, 1, 0, 0),
                                     simd.float4(0, 0, 1, 0),
                                     simd.float4(trans.x, trans.y, trans.z, 1)))
}

func perspective4x4(fovY: Float, aspect: Float, nearZ: Float, farZ: Float) -> matrix_float4x4 {
    let yscale = 1.0 / tan(fovY * 0.5), xscale = yscale / aspect
    let q = farZ / (farZ - nearZ)

    return matrix_float4x4(columns: (float4(xscale, 0, 0, 0),
                                     float4(0, yscale, 0, 0),
                                     float4(0, 0, q, 1),
                                     float4(0, 0, q * -nearZ, 0)))
}

func matrix_make(_ column0: float3, _ column1: float3, _ column2: float3) -> matrix_float4x4 {
    return matrix_float4x4(columns: (float4(column0.x, column0.y, column0.z, 0.0),
                                     float4(column1.x, column1.y, column1.z, 0.0),
                                     float4(column2.x, column2.y, column2.z, 0.0),
                                     float4(0.0, 0.0, 0.0, 1.0)))
}

func matrix_make(rotation: matrix_float4x4, column3: float4) -> matrix_float4x4 {
    return matrix_float4x4(columns: (rotation.columns.0, rotation.columns.1,
                                     rotation.columns.2, float4(column3.x, column3.y, column3.z, column3.w)))
}

func get3x3(fullmat: matrix_float4x4) -> matrix_float3x3 {
    return matrix_float3x3(columns: (float3(fullmat.columns.0.x, fullmat.columns.0.y, fullmat.columns.0.z),
                                     float3(fullmat.columns.1.x, fullmat.columns.1.y, fullmat.columns.1.z),
                                     float3(fullmat.columns.2.x, fullmat.columns.2.y, fullmat.columns.2.z)))
}

func matrix_float4x4_rotation(_ radians: Float, _ axis: float3) -> matrix_float4x4 {
    let axisNormalized = normalize(axis)
    let ct = cosf(radians)
    let st = sinf(radians)
    let ci = 1 - ct
    let x = axisNormalized.x, y = axisNormalized.y, z = axisNormalized.z
    let column0 = float3(ct + x * x * ci, y * x * ci + z * st, z * x * ci - y * st)
    let column1 = float3(x * y * ci - z * st, ct + y * y * ci, z * y * ci + x * st)
    let column2 = float3(x * z * ci + y * st, y * z * ci - x * st, ct + z * z * ci)
    return matrix_make(column0, column1, column2)
}
