/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Metal utility functions for setting up the game engine state
*/

import Foundation
import MetalKit

func getFuncConstantsForDrawDataSet(meshData: MeshData, useMaterials: Bool) -> MTLFunctionConstantValues {
    var has_base_color_map = false
    var has_normal_map = false
    var has_metallic_map = false
    var has_roughness_map = false
    var has_ambient_occlusion_map = false
    var has_irradiance_map = false

    // -- condition all subdata since we only do a pipelinestate once per DrawData
    if useMaterials {
        for material in meshData.materials {
            has_base_color_map = has_base_color_map || (material.baseColor.1 != nil)
            has_normal_map = has_normal_map || (material.normalMap != nil)
            has_metallic_map = has_metallic_map || (material.metallic.1 != nil)
            has_roughness_map = has_roughness_map || (material.roughness.1 != nil)
            has_ambient_occlusion_map = has_ambient_occlusion_map || (material.ambientOcclusionMap != nil)

            // -- currently not featured
            has_irradiance_map = false
        }
    }

    let constantValues = MTLFunctionConstantValues()
    constantValues.setConstantValue(&has_base_color_map, type: .bool, index: Int(kFunctionConstantBaseColorMapIndex.rawValue))
    constantValues.setConstantValue(&has_normal_map, type: .bool, index: Int(kFunctionConstantNormalMapIndex.rawValue))
    constantValues.setConstantValue(&has_metallic_map, type: .bool, index: Int(kFunctionConstantMetallicMapIndex.rawValue))
    constantValues.setConstantValue(&has_roughness_map, type: .bool, index: Int(kFunctionConstantRoughnessMapIndex.rawValue))
    constantValues.setConstantValue(&has_ambient_occlusion_map, type: .bool, index: Int(kFunctionConstantAmbientOcclusionMapIndex.rawValue))
    constantValues.setConstantValue(&has_irradiance_map, type: .bool, index: Int(kFunctionConstantIrradianceMapIndex.rawValue))
    return constantValues
}
