/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Implementation of a game engine
*/

import Cocoa
import MetalKit

class GameViewController: NSViewController, MTKViewDelegate {
    enum Constants {
        static let maxInFlightBuffers = 3
        static let maxPaletteSize = 100

        // The 256 byte aligned size of our uniform structure
        static let alignedPerFrameUniformsSize = (MemoryLayout<PerFrameUniforms>.stride & ~0xFF) + 0x100
        static let alignedMaterialSize = (MemoryLayout<MaterialUniforms>.stride & ~0xFF) + 0x100
        static let alignedMeshUniformSize = (MemoryLayout<MeshUniforms>.stride & ~0xFF) + 0x100
        static let alignedSkyUniformsSize = (MemoryLayout<SkyUniform>.stride & ~0xFF) + 0x100
        static let alignedPaletteSize = (MemoryLayout<matrix_float4x4>.stride & ~0xFF) + 0x100
    }

    var device: MTLDevice!

    var commandQueue: MTLCommandQueue!
    var pipelineStates = [MTLRenderPipelineState]()
    var skyPipeLineState: MTLRenderPipelineState!
    var skinnedPipeLineState: MTLRenderPipelineState!
    var depthStencilState: MTLDepthStencilState!
    var skyDepthStencilState: MTLDepthStencilState!

    var scnData1 = Baker()

    let inflightSemaphore = DispatchSemaphore(value: Constants.maxInFlightBuffers)
    var cameraRotation = 0.0
    var frameNumber = 0
    var perFrameUniformBufferOffset = 0
    var bufferIndex = 0
    var perFrameUniformBufferAddress: UnsafeMutableRawPointer!
    var dynamicPerFrameUniformBuffer: MTLBuffer!
    var skyUniformBufferOffset = 0
    var skyUniformBufferAddress: UnsafeMutableRawPointer!
    var skyDynamicUniformBuffer: MTLBuffer!
    var meshUniformBufferOffset = 0
    var meshUniformBufferAddress: UnsafeMutableRawPointer!
    var meshDynamicUniformBuffer: MTLBuffer!
    var paletteBufferOffset = 0
    var paletteBufferAddress: UnsafeMutableRawPointer!
    var paletteBuffer: MTLBuffer!
    var textureLoader: MTKTextureLoader!
    var skyTexture: MTLTexture!
    var skyCubeVBuffer: MTLBuffer!
    var skyCubeIBuffer: MTLBuffer!
    var totalMeshTransforms = 0
    var useSky = false
    var useSkinning = false
    var useAnimation = false
    var useMaterials = false

    // -- dynamic data
    var instData: MTLBuffer!

    // List of parent child relational indices.
    var parentIndices = [Int?]()

    // Flattened hierarchical transform data.
    var nodeTransforms = [NodeTransform]()

    var meshGPUData = MeshGPUData()

    override func viewDidLoad() {
        super.viewDidLoad()

        device = MTLCreateSystemDefaultDevice()

        guard device != nil else {
            print("Metal not supported")
            return
        }

        let view = self.view as! MTKView
        view.delegate = self
        view.device = device
        view.sampleCount = 4
        view.colorPixelFormat = .bgra8Unorm_srgb
        view.depthStencilPixelFormat = .depth32Float_stencil8

        if !loadAssets() {
            print("Failed to load assets, exiting the game engine")
            exit(-11)
        }
    }

    func createMTLTexture(_ textureString: String) -> MTLTexture? {
        do {
            guard let textureURL = URL(string: textureString) else { return nil }
            return try textureLoader.newTexture(withContentsOf: textureURL, options: nil)
        } catch {
            print("Unable to loader texture with texturePath \(textureString) with error \(error)")
        }

        return nil
    }

    func loadSky() {
        skyCubeVBuffer = device.makeBuffer(bytes: &sky_vertices, length: 24 * 4 * 3, options: [])
        skyCubeIBuffer = device.makeBuffer(bytes: &sky_indices, length: 36 * 2, options: [])
    }

    func loadMeshes() {
        if useSky {
            loadSky()
        }

        for vtxBuffer in scnData1.vertexBuffers {
            vtxBuffer.withUnsafeBytes { (bytes: UnsafePointer<UInt8>) in
                let buffer = device.makeBuffer(bytes: bytes, length: vtxBuffer.count, options: .storageModeShared)
                meshGPUData.vtxBuffers.append(buffer)
            }

        }

        for idxBuffer in scnData1.indexBuffers {
            idxBuffer.withUnsafeBytes { (bytes: UnsafePointer<UInt8>) in
                let buffer = device.makeBuffer(bytes: bytes, length: idxBuffer.count, options: .storageModeShared)
                meshGPUData.indexBuffers.append(buffer)
            }
        }

        for texturePath in scnData1.texturePaths {
            meshGPUData.textures.append(createMTLTexture(texturePath))
        }

        var instStartIdx = 0
        var paletteStartIdx = 0
        for (meshIdx, meshData) in scnData1.meshes.enumerated() {
            var drawData = DrawData()
            drawData.vbCount = meshData.vbCount
            drawData.vbStartIdx = meshData.vbStartIdx
            drawData.ibStartIdx = meshData.ibStartIdx
            drawData.instCount = !scnData1.instanceCount.isEmpty ? scnData1.instanceCount[meshIdx] : 1
            drawData.instBufferStartIdx = instStartIdx
            if !scnData1.meshSkinIndices.isEmpty,
                let paletteIndex = scnData1.meshSkinIndices[instStartIdx] {
                drawData.paletteSize = scnData1.skins[paletteIndex].jointPaths.count
                drawData.paletteStartIndex = paletteStartIdx
                paletteStartIdx += drawData.paletteSize * drawData.instCount
            }
            instStartIdx += drawData.instCount
            useMaterials = (!meshData.materials.isEmpty)
            for subIndex in 0..<meshData.idxCounts.count {
                var subData = DrawSubData()
                subData.idxCount = meshData.idxCounts[subIndex]
                subData.idxType = convertToMtlIndexType(mdlIdxBitDepth: meshData.idxTypes[subIndex])
                subData.materialUniforms = useMaterials ? convertToMaterialUniform(meshData.materials[subIndex])
                                                          : MaterialUniforms()
                subData.baseColorTexIdx = useMaterials ? meshData.materials[subIndex].baseColor.1 : nil
                subData.normalTexIdx = useMaterials ? meshData.materials[subIndex].normalMap : nil
                subData.aoTexIdx = useMaterials ? meshData.materials[subIndex].ambientOcclusionMap : nil
                subData.roughTexIdx = useMaterials ? meshData.materials[subIndex].roughness.1 : nil
                subData.metalTexIdx = useMaterials ? meshData.materials[subIndex].metallic.1 : nil
                drawData.subData.append(subData)
            }

            meshGPUData.drawData.append(drawData)
        }

        totalMeshTransforms = scnData1.meshNodeIndices.count
    }

    func createVertexDescriptor(with vtxDesc: [MDLVertexDescriptor]) -> MTLVertexDescriptor {
        let mtlVertexDescriptor = MTKMetalVertexDescriptorFromModelIO(vtxDesc[0])
        return mtlVertexDescriptor!
    }

    func loadAssets() -> Bool {
        // deserialize data
        var urlpaths = [URL]()
        for i in 1..<CommandLine.arguments.count {
            urlpaths.append(URL(fileURLWithPath: CommandLine.arguments[i]))
        }
        if let archivedSceneData = (NSKeyedUnarchiver.unarchiveObject(
            withFile: urlpaths[0].path) as? Baker.CodingWrapper) {
            scnData1 = archivedSceneData.scene!
        } else {
            print("Did not find baked assets, please run Baker first!")
            return false
        }

        textureLoader = MTKTextureLoader(device: device)
        loadMeshes()

        let perFrameUniformBufferSize = Constants.alignedPerFrameUniformsSize * Constants.maxInFlightBuffers
        let skyUniformBufferSize = Constants.alignedSkyUniformsSize * Constants.maxInFlightBuffers
        let meshUniformBufferSize = Constants.alignedMeshUniformSize * Constants.maxInFlightBuffers * totalMeshTransforms
        let paletteBufferSize = Constants.alignedPaletteSize * Constants.maxInFlightBuffers * Constants.maxPaletteSize

        dynamicPerFrameUniformBuffer = device.makeBuffer(length: perFrameUniformBufferSize,
                                                         options: [])
        dynamicPerFrameUniformBuffer.label = "PerFrameUniformBuffer"

        skyDynamicUniformBuffer = device.makeBuffer(length: skyUniformBufferSize, options: [])
        skyDynamicUniformBuffer.label = "SkyUniformBuffer"

        meshDynamicUniformBuffer = device.makeBuffer(length: meshUniformBufferSize, options: [])
        meshDynamicUniformBuffer.label = "PerMeshUniformBuffer"

        paletteBuffer = device.makeBuffer(length: paletteBufferSize, options: [])
        paletteBuffer.label = "PaletteBuffer"

        let defaultLibrary = device.makeDefaultLibrary()!
        let view = self.view as! MTKView
        let vertexDescriptor = createVertexDescriptor(with: scnData1.vertexDescriptors)

        // -- create sky pipeline state
        let skyPipeLineStateDesc = MTLRenderPipelineDescriptor()
        let skyFragFunc = defaultLibrary.makeFunction(name: "fragment_sky")
        let skyVertFunc = defaultLibrary.makeFunction(name: "vertex_sky")

        let mtlVertexDescriptor = MTLVertexDescriptor()
        mtlVertexDescriptor.attributes[0].bufferIndex = 0
        mtlVertexDescriptor.attributes[0].format = .float3
        mtlVertexDescriptor.attributes[0].offset = 0

        mtlVertexDescriptor.layouts[0].stride = 12
        mtlVertexDescriptor.layouts[0].stepFunction = .perVertex
        mtlVertexDescriptor.layouts[0].stepRate = 1

        skyPipeLineStateDesc.vertexDescriptor = mtlVertexDescriptor
        skyPipeLineStateDesc.vertexFunction = skyVertFunc
        skyPipeLineStateDesc.fragmentFunction = skyFragFunc
        skyPipeLineStateDesc.colorAttachments[0].pixelFormat = view.colorPixelFormat
        skyPipeLineStateDesc.depthAttachmentPixelFormat = view.depthStencilPixelFormat
        skyPipeLineStateDesc.stencilAttachmentPixelFormat = view.depthStencilPixelFormat
        skyPipeLineStateDesc.sampleCount = Int(view.sampleCount)
        do {
            skyPipeLineState = try device.makeRenderPipelineState(descriptor: skyPipeLineStateDesc)
        } catch let error {
            print("Failed to create sky pipline state, error \(error)")
        }

        for (drawIdx, drawData) in meshGPUData.drawData.enumerated() {
            let pipelineStateDescriptor = MTLRenderPipelineDescriptor()
            do {
                let funcConstants = getFuncConstantsForDrawDataSet(meshData: scnData1.meshes[drawIdx], useMaterials: useMaterials)
                let vertexName = (drawData.paletteStartIndex != nil) ? "vertex_skinned" : "vertexShader"
                let fragFunc = try defaultLibrary.makeFunction(name: "fragmentShader",
                                                               constantValues: funcConstants)
                let vertFunc = try defaultLibrary.makeFunction(name: vertexName,
                                                               constantValues: funcConstants)
                pipelineStateDescriptor.vertexDescriptor = vertexDescriptor
                pipelineStateDescriptor.vertexFunction = vertFunc
                pipelineStateDescriptor.fragmentFunction = fragFunc
                pipelineStateDescriptor.colorAttachments[0].pixelFormat = view.colorPixelFormat
                pipelineStateDescriptor.depthAttachmentPixelFormat = view.depthStencilPixelFormat
                pipelineStateDescriptor.stencilAttachmentPixelFormat = view.depthStencilPixelFormat
                pipelineStateDescriptor.sampleCount = Int(view.sampleCount)
            } catch let error {
                print("Failed to create pipeline state descriptor, error \(error)")
            }

            do {
                try pipelineStates.append(device.makeRenderPipelineState(descriptor: pipelineStateDescriptor))
            } catch let error {
                print("Failed to create pipeline state, error \(error)")
            }
        }

        let depthStencilStateDescriptor = MTLDepthStencilDescriptor()
        depthStencilStateDescriptor.depthCompareFunction = MTLCompareFunction.less
        depthStencilStateDescriptor.isDepthWriteEnabled = true
        depthStencilState = device.makeDepthStencilState(descriptor: depthStencilStateDescriptor)

        let skyDepthStencilStateDescriptor = MTLDepthStencilDescriptor()
        skyDepthStencilStateDescriptor.depthCompareFunction = MTLCompareFunction.less
        skyDepthStencilStateDescriptor.isDepthWriteEnabled = false
        skyDepthStencilState = device.makeDepthStencilState(descriptor: skyDepthStencilStateDescriptor)

        commandQueue = device.makeCommandQueue()

        return true
    }

    func updateDynamicBufferState() {
        // Update the location(s) to which we'll write to in our dynamically changing Metal buffers for
        //   the current frame (i.e. update our slot in the ring buffer used for the current frame)
        bufferIndex = (bufferIndex + 1) % Constants.maxInFlightBuffers
        perFrameUniformBufferOffset = Constants.alignedPerFrameUniformsSize * bufferIndex
        perFrameUniformBufferAddress = dynamicPerFrameUniformBuffer.contents() + perFrameUniformBufferOffset

        // -- sky uniforms
        skyUniformBufferOffset = Constants.alignedSkyUniformsSize * bufferIndex
        skyUniformBufferAddress = skyDynamicUniformBuffer.contents() + skyUniformBufferOffset

        // -- mesh uniforms
        meshUniformBufferOffset = Constants.alignedMeshUniformSize * bufferIndex * totalMeshTransforms
        meshUniformBufferAddress = meshDynamicUniformBuffer.contents() + meshUniformBufferOffset

        // -- palette uniforms
        paletteBufferOffset = Constants.alignedPaletteSize * bufferIndex * Constants.maxPaletteSize
        paletteBufferAddress = paletteBuffer.contents() + paletteBufferOffset
    }

    func updateConstantUniforms() {
        let perFrameUniforms = perFrameUniformBufferAddress!.bindMemory(to: PerFrameUniforms.self, capacity: 1)
        let skyUniforms = skyUniformBufferAddress!.bindMemory(to: SkyUniform.self, capacity: 1)

        perFrameUniforms.initialize(to: PerFrameUniforms())
        skyUniforms.initialize(to: SkyUniform())

        let aspect = abs(Float(view.bounds.size.width / view.bounds.size.height))
        let projectionMatrix = perspective4x4(fovY: 65.0 * (Float.pi / 180.0),
                                              aspect: aspect,
                                              nearZ: 10.0, farZ: 2_000_000.0)
        let viewMatRotation = matrix_float4x4_rotation(Float(cameraRotation), float3(0, 1, 0))
        let cameraPosition = simd_mul(viewMatRotation, float4(-6300.0, 4000.0, -8500.0, 0.0))
        let cameraLookAt = normalize(float3(0.0, 0.0, 0.0) - float3(cameraPosition.x,
                                                                    cameraPosition.y,
                                                                    cameraPosition.z))
        var cameraUp = float3(0.0, 1.0, 0.0)
        let cameraRight = normalize(simd_cross(cameraUp, cameraLookAt))
        cameraUp = simd_cross(cameraLookAt, cameraRight)
        let cameraMatrix = matrix_make(cameraRight, cameraUp, float3(cameraLookAt.x, cameraLookAt.y, cameraLookAt.z))
        let viewSpace = simd_transpose(cameraMatrix)
        let finalViewTranslation = simd_mul(viewSpace, float4(-cameraPosition.x,
                                                              -cameraPosition.y,
                                                              -cameraPosition.z, 1.0))
        let viewMatrix = matrix_make(rotation: viewSpace, column3: finalViewTranslation)
        let skyWorldViewMatrix = simd_transpose(viewMatRotation)

        let skyViewProjectionMatrix = simd_mul(projectionMatrix, skyWorldViewMatrix)

        perFrameUniforms[0].viewMatrix = viewMatrix
        perFrameUniforms[0].viewProjectionMatrix = simd_mul(projectionMatrix, viewMatrix)
        perFrameUniforms[0].directionalLightInvDirection = normalize(vector_float3(sin(0.65) * sin(-0.25),
                                                                                   cos(0.65), sin(0.65) * cos(-0.25)))
        perFrameUniforms[0].lightCol = vector_float3(4.0, 4.0, 4.0)
        perFrameUniforms[0].cameraPos = vector_float3(cameraPosition.x, cameraPosition.y, cameraPosition.z)

        skyUniforms[0].worldViewProjectionMatrix = skyViewProjectionMatrix
    }

    func updateAnimatedCharacters() {
        let capacity = Constants.alignedPaletteSize * Constants.maxPaletteSize

        let boundPaletteData = paletteBufferAddress.bindMemory(to: matrix_float4x4.self, capacity: capacity)

        let paletteData = UnsafeMutableBufferPointer<matrix_float4x4>(
            start: boundPaletteData,
            count: Constants.maxPaletteSize
        )

        var jointPaletteOffset = 0
        for skin in scnData1.skins {
            if let animationIndex = skin.animationIndex {
                let curAnimation = scnData1.skeletonAnimations[animationIndex]
                let worldPose = evaluateAnimation(curAnimation, at: (Double(frameNumber) * 1.0 / 60.0))
                let matrixPalette = evaluateMatrixPalette(worldPose, skin)

                for k in 0..<matrixPalette.count {
                    paletteData[k + jointPaletteOffset] = matrixPalette[k]
                }

                jointPaletteOffset += matrixPalette.count
            }
        }
    }

    func getCurrentTransform(atIndex tfIdx: Int) -> matrix_float4x4 {
        var localTransform: matrix_float4x4
        if !scnData1.localTransformAnimationIndices.isEmpty,
           let localTransformIndice = scnData1.localTransformAnimationIndices[tfIdx] {
            let keyFrameIdx = lowerBoundKeyframeIndex(scnData1.sampleTimes,
                                                      key: Double(frameNumber) * 1.0 / 60.0)!
            localTransform = scnData1.localTransformAnimations[localTransformIndice][keyFrameIdx]
        } else {
            localTransform = scnData1.localTransforms[tfIdx]
        }

        return localTransform
    }

    func updateTransforms() {
        let numParents = scnData1.parentIndices.count
        var worldTransforms = [matrix_float4x4](repeating: matrix_float4x4(),
                                                count: numParents)

        // -- traverse the scene and update the node transforms
        for (tfIdx, parentIndexOptional) in scnData1.parentIndices.enumerated() {
            let localTransform = getCurrentTransform(atIndex: tfIdx)
            if let parentIndex = parentIndexOptional {
                let parentTransform = worldTransforms[parentIndex]
                let worldMatrix = simd_mul(parentTransform, localTransform)
                worldTransforms[tfIdx] = worldMatrix

            } else {
                worldTransforms[tfIdx] = localTransform
            }
        }

        // -- layout mesh only transforms
        let meshTransforms = meshUniformBufferAddress.bindMemory(to: MeshUniforms.self, capacity: scnData1.meshNodeIndices.count)

        for (curIndex, meshIndex) in scnData1.meshNodeIndices.enumerated() {
            let worldMatrix = worldTransforms[meshIndex]
            let worldMat3x3 = get3x3(fullmat: worldMatrix)
            meshTransforms[curIndex].worldMatrix = worldMatrix
            meshTransforms[curIndex].normalMatrix = worldMat3x3
        }
    }

    func updateGameState(frameTime: Double) {
        // -- Update any game state (including updating dynamically changing Metal buffer)
        // -- update uniforms that stay constant for all meshes
        updateConstantUniforms()

        // -- update scene graph transforms
        updateTransforms()

        // -- update skinned meshes
        updateAnimatedCharacters()
    }

    func update() {
        updateDynamicBufferState()
        updateGameState(frameTime: Double(frameNumber) / 60.0)

        frameNumber = (frameNumber + 1) % 300
    }

    func setMeshVertexBuffers(withREncoder renderEncoder: MTLRenderCommandEncoder, drawData: DrawData) {
        for vtxBufferIdx in 0..<drawData.vbCount {
            renderEncoder.setVertexBuffer(meshGPUData.vtxBuffers[drawData.vbStartIdx + vtxBufferIdx],
                                          offset: 0, index: vtxBufferIdx)
        }
    }

    func setTextures(withREncoder renderEncoder: MTLRenderCommandEncoder, withSubData drawSubData: DrawSubData) {
        if let baseColorTexIdx = drawSubData.baseColorTexIdx {
            renderEncoder.setFragmentTexture(meshGPUData.textures[baseColorTexIdx],
                                             index: Int(kTextureIndexBaseColor.rawValue))
        }

        if let aoTexIdx = drawSubData.aoTexIdx {
            renderEncoder.setFragmentTexture(meshGPUData.textures[aoTexIdx],
                                             index: Int(kTextureIndexAmbientOcclusion.rawValue))
        }

        if let normalTexIdx = drawSubData.normalTexIdx {
            renderEncoder.setFragmentTexture(meshGPUData.textures[normalTexIdx],
                                             index: Int(kTextureIndexNormal.rawValue))
        }

        if let roughTexIdx = drawSubData.roughTexIdx {
            renderEncoder.setFragmentTexture(meshGPUData.textures[roughTexIdx],
                                             index: Int(kTextureIndexRoughness.rawValue))
        }

        if let metalTexIdx = drawSubData.metalTexIdx {
            renderEncoder.setFragmentTexture(meshGPUData.textures[metalTexIdx],
                                             index: Int(kTextureIndexMetallic.rawValue))
        }

    }

    func drawDataSets(withREncoder renderEncoder: MTLRenderCommandEncoder, drawData: DrawData) {
        for drawDataSubIndex in 0..<drawData.subData.count {
            let idxCount = Int(drawData.subData[drawDataSubIndex].idxCount)
            let idxType = drawData.subData[drawDataSubIndex].idxType
            let ibOffset = drawData.ibStartIdx
            let indexBuffer = meshGPUData.indexBuffers[ibOffset + drawDataSubIndex]
            var materialUniforms = drawData.subData[drawDataSubIndex].materialUniforms

            // -- set textures based off material flags
            setTextures(withREncoder: renderEncoder, withSubData: drawData.subData[drawDataSubIndex])

            renderEncoder.setFragmentBytes(&materialUniforms, length: Constants.alignedMaterialSize,
                                           index: Int(kBufferIndexMaterialUniforms.rawValue))

            renderEncoder.drawIndexedPrimitives(type: .triangle, indexCount: idxCount, indexType: idxType,
                                                indexBuffer: indexBuffer, indexBufferOffset: 0,
                                                instanceCount: drawData.instCount)
        }
    }

    func renderSky(withREncoder renderEncoder: MTLRenderCommandEncoder) {
        renderEncoder.setVertexBuffer(skyDynamicUniformBuffer, offset: skyUniformBufferOffset,
                                      index: Int(kBufferIndexSkyUniforms.rawValue))
        renderEncoder.setDepthStencilState(skyDepthStencilState)
        renderEncoder.setRenderPipelineState(skyPipeLineState)
        renderEncoder.setFragmentTexture(skyTexture, index: Int(kTextureIndexSkyMap.rawValue))
        renderEncoder.setVertexBuffer(skyCubeVBuffer, offset: 0, index: 0)
        renderEncoder.drawIndexedPrimitives(type: .triangle, indexCount: 36, indexType: .uint16,
                                            indexBuffer: skyCubeIBuffer, indexBufferOffset: 0)
    }

    func setUniforms(withREncoder renderEncoder: MTLRenderCommandEncoder) {
        // -- set all mesh uniforms and per frame uniforms
        renderEncoder.setVertexBuffer(dynamicPerFrameUniformBuffer, offset: perFrameUniformBufferOffset,
                                      index: Int(kBufferIndexPerFrameUniforms.rawValue))
        renderEncoder.setVertexBuffer(meshDynamicUniformBuffer, offset: meshUniformBufferOffset,
                                      index: Int(kBufferIndexPerMeshUniforms.rawValue))
        renderEncoder.setFragmentBuffer(dynamicPerFrameUniformBuffer, offset: perFrameUniformBufferOffset,
                                        index: Int(kBufferIndexPerFrameUniforms.rawValue))

        // -- set palette buffer for skinned meshes
        renderEncoder.setVertexBuffer(paletteBuffer, offset: paletteBufferOffset,
                                      index: Int(kBufferIndexMeshPalettes.rawValue))
    }

    func renderMesh(withREncoder renderEncoder: MTLRenderCommandEncoder) {
        for (drawDataIdx, drawData) in meshGPUData.drawData.enumerated() {
            renderEncoder.setRenderPipelineState(pipelineStates[drawDataIdx])

            // -- set the palette offset into
            if var paletteStartIdx = drawData.paletteStartIndex {
                renderEncoder.setVertexBytes(&paletteStartIdx, length: 8,
                                             index: Int(kBufferIndexMeshPaletteIndex.rawValue))
                var paletteSize = drawData.paletteSize
                renderEncoder.setVertexBytes(&paletteSize, length: 8,
                                             index: Int(kBufferIndexMeshPaletteSize.rawValue))
            }

            var instBufferStartIdx = drawData.instBufferStartIdx
            renderEncoder.setVertexBytes(&instBufferStartIdx, length: 8,
                                         index: Int(kBufferIndexMeshUniformIndex.rawValue))

            // -- set mesh vertex data
            setMeshVertexBuffers(withREncoder: renderEncoder, drawData: drawData)

            drawDataSets(withREncoder: renderEncoder, drawData: drawData)
        }
    }

    func setMeshState(withREncoder renderEncoder: MTLRenderCommandEncoder) {
        renderEncoder.setDepthStencilState(depthStencilState)
    }

    func render(withREncoder renderEncoder: MTLRenderCommandEncoder) {
        // -- render sky cube
        if useSky {
            renderSky(withREncoder: renderEncoder)
        }

        // -- set mesh state
        setMeshState(withREncoder: renderEncoder)

        // -- set uniforms
        setUniforms(withREncoder: renderEncoder)

        // -- render all meshes
        renderMesh(withREncoder: renderEncoder)
    }

    func draw(in view: MTKView) {
        _ = inflightSemaphore.wait(timeout: .distantFuture)

        update()

        let commandBuffer = commandQueue.makeCommandBuffer()
        commandBuffer.addCompletedHandler { [weak self] _ in
            if let strongSelf = self {
                strongSelf.inflightSemaphore.signal()
            }
        }

        if let renderPassDescriptor = view.currentRenderPassDescriptor, let currentDrawable = view.currentDrawable {
            let renderEncoder = commandBuffer.makeRenderCommandEncoder(descriptor: renderPassDescriptor)
            renderEncoder.pushDebugGroup("draw meshes")

            // -- render entry point
            render(withREncoder: renderEncoder)

            renderEncoder.popDebugGroup()
            renderEncoder.endEncoding()

            commandBuffer.present(currentDrawable)
        }

        commandBuffer.commit()
    }

    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) { }
}
