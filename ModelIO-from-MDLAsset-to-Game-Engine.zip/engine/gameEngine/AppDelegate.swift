/*
See LICENSE folder for this sample’s licensing information.

Abstract:
App delegate
*/

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {
    @IBOutlet weak var window: NSWindow!
}
