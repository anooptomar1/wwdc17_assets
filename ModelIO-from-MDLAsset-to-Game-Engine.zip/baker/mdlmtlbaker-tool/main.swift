/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Entry point for the baker
*/

import Cocoa
import ModelIO

let mdlVertexDescriptor = MDLVertexDescriptor()

// Here we describe vertex attributes, format describes the stride
// the offset describes what byte offset into the buffer the attribute starts
// bufferIndex desribes which vertex buffer the attribute will reside
mdlVertexDescriptor.attributes = [
    MDLVertexAttribute(name: MDLVertexAttributePosition, format: .float3, offset: 0, bufferIndex: 0),
    MDLVertexAttribute(name: MDLVertexAttributeNormal, format: .float3, offset: 12, bufferIndex: 0),
    MDLVertexAttribute(name: MDLVertexAttributeTextureCoordinate, format: .float2, offset: 24, bufferIndex: 0),
    MDLVertexAttribute(name: MDLVertexAttributeJointIndices, format: .uShort4, offset: 32, bufferIndex: 0),
    MDLVertexAttribute(name: MDLVertexAttributeJointWeights, format: .float4, offset: 40, bufferIndex: 0)
]

mdlVertexDescriptor.layouts[0] = MDLVertexBufferLayout(stride: 56)

let assetURL = URL(fileURLWithPath: CommandLine.arguments[1])

// create an MDLAsset using the file url given
let asset = MDLAsset(
    url: assetURL,
    vertexDescriptor: mdlVertexDescriptor,
    bufferAllocator: nil,
    preserveTopology: false,
    error: nil
)

let sceneData = Baker(asset: asset)

// Serialize data.
NSKeyedArchiver.archiveRootObject(
    Baker.CodingWrapper(scene: sceneData),
    toFile: assetURL.deletingLastPathComponent().appendingPathComponent("scene.dat").path
)
