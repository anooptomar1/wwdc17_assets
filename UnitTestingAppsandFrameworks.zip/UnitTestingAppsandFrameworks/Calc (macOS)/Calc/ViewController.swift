//
//  ViewController.swift
//  Calc (macOS)
//
//  Created by linda ouandji on 3/27/17.
//  Copyright © 2017 My Apps. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }


}

