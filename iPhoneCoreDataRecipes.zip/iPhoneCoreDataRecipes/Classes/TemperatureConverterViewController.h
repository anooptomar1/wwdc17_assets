/*
  Copyright (C) 2017 Apple Inc. All Rights Reserved.
  See LICENSE.txt for this sample’s licensing information
  
  Abstract:
  View controller to display cooking temperatures in Centigrade, Fahrenheit, and Gas Mark.
  */

@interface TemperatureConverterViewController : UITableViewController

@end
