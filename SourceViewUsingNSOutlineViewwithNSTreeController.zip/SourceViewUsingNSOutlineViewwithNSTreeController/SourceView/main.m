/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Main source file for this sample.
 */

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **) argv);
}
