/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Generic child node object used with NSOutlineView and NSTreeController.
 */

#import "BaseNode.h"

@interface ChildNode : BaseNode

@end
