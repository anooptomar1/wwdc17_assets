/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 The primary or main window controller class for this sample.
 */

#import "MyWindowController.h"

@implementation MyWindowController

- (void)windowDidLoad
{
    [super windowDidLoad];
    
    // do anything else here at load time
}

@end
