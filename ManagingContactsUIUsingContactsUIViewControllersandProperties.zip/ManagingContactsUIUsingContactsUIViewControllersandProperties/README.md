# ManagingContactsUI: Using ContactsUI View Controllers and Properties

This sample is a set of iOS sample code projects that demonstrates how to use
ContactsUI view controllers and properties.

## ContactPickerViewController

ContactsPickerViewController demonstrates how to:
+ Implement single and multiselection of contacts using CNContactPickerViewController.
+ Implement single and multiselection of properties using CNContactPickerViewController.
+ Use the displayedPropertyKeys property.

## ContactPickerViewControllerWithPredicates

ContactPickerViewControllerWithPredicates demonstrates how to use the
predicateForEnablingContact:, predicate​For​Selection​Of​Contact, and 
predicateForSelectionOfProperty: properties for selecting contacts and properties.

## ContactViewController 

ContactViewController demonstrates how to:  
+ Create and display a new contact, an unknown contact, or existing contact using
  CNContactViewController.
+ Dismiss CNContactViewController when using init(for​New​Contact:​) to create a new 
  contact.
+ Use the allowsEditing and allowsActions properties.
+ Use the highlight​Property(with​Key:​identifier:​) property to highlight a contact's 
  property (iPhone number).
+ Prevent users from performing default actions such as dialing a phone number 
  associated with a selected contact.

## Requirements

### Build

Xcode 8.3 or later; iOS 10.3 SDK or later

### Runtime

iOS 9.3 or later

Copyright (C) 2017 Apple Inc. All rights reserved.
