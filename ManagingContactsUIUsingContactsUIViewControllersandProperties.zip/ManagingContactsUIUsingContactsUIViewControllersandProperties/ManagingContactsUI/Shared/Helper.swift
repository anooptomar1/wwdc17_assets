/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 A helper class that is used to create an alert.
*/

import UIKit

class Helper {
    // MARK: - Create Alert
    
    /// - returns: An alert with a given title and message.
    class func alert(with message: String) -> UIAlertController {
        let alert = UIAlertController(title: AppConfiguration.Messages.status, message: message, preferredStyle: .actionSheet)
        
        let action = UIAlertAction(title: NSLocalizedString(AppConfiguration.Messages.okButton, comment: message),
                                   style: .default,
                                 handler: nil)
        
        alert.addAction(action)
        return alert
    }
}
