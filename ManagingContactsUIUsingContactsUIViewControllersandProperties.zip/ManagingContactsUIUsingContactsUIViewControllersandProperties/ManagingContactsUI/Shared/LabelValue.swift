/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Structure used to represent a label and its value.
*/

import Foundation

struct LabelValue {
    // MARK: - Properties
  
    var label: String?
    var value: String
    
    // MARK: - Initializers
    
    init(label: String? = nil, value: String) {
        self.label = label
        self.value = value
    }
}
