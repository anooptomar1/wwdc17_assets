/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Structure used to represent a section of LabelValue items.
*/

import Foundation

struct Section {
    // MARK: - Properties
    
    /// Title of the section.
    var title: String?
    
    /// Contains a section  of LabelValue items.
    var section: [LabelValue]
    
    // MARK: - Initializers
    
    init(title: String? = nil, section: [LabelValue]) {
        self.title = title
        self.section = section
    }
}
