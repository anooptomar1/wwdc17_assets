/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Handles the application's configuration information.
*/

import Foundation

class AppConfiguration {
    // MARK: - AppConfiguration.TableViewCellLabels
    
    struct TableViewCellLabels {
        static let contact = "Contact:"
        static let key = "Key:"
        static let label = "Label:"
        static let namelessContact = "No Name"
        static let value = "Value:"
    }
    
    // MARK: - AppConfiguration.TableViewCellLabels
    
    struct TableViewCellIdentifiers {
        static let cell = "cellID"
    }
    
    // MARK: - AppConfiguration.Messages
    
    struct Messages {
        static let accessDeniedOrRestricted = "Access denied or restricted."
        static let added = "was successfully added."
        static let couldNotFind = " Could not find"
        static let error = "Error: "
        static let dismissPicker = "Dismissing contact picker view controller."
        static let inContacts = "in Contacts."
        static let okButton = "OK"
        static let status = "Status"
        static let wasSelected = "was selected."
    }
}
